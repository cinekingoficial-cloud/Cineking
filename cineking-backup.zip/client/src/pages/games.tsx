import { useGames } from "@/hooks/use-games";
import { motion } from "framer-motion";
import { Clock, Trophy, Tv, Calendar, Loader2 } from "lucide-react";
import { format, isToday, isTomorrow } from "date-fns";
import { ptBR } from "date-fns/locale";

function formatGameDate(dateStr: string) {
  const [day, month, year] = dateStr.split('/');
  if (!day || !month || !year) return dateStr;
  const d = new Date(Number(year), Number(month) - 1, Number(day));
  if (isToday(d)) return "Hoje";
  if (isTomorrow(d)) return "Amanhã";
  return format(d, "EEEE, dd/MM", { locale: ptBR });
}

function GameCard({ game, index }: { game: any; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="glass-card rounded-3xl overflow-hidden"
    >
      {game.bannerUrl ? (
        <div className="relative h-44 overflow-hidden">
          <img 
            src={game.bannerUrl} 
            alt={`${game.homeTeam} vs ${game.awayTeam}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
            <span className="text-xs font-bold text-primary bg-black/60 px-2 py-1 rounded-full border border-primary/30">
              {game.championship}
            </span>
            <span className="text-xs text-white/80 bg-black/60 px-2 py-1 rounded-full">
              {formatGameDate(game.gameDate)}
            </span>
          </div>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-primary/20 via-black to-primary/10 h-3" />
      )}

      <div className="p-5">
        {!game.bannerUrl && (
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-primary bg-primary/10 border border-primary/20 px-3 py-1 rounded-full">
              {game.championship}
            </span>
            <span className="text-xs text-white/50">{formatGameDate(game.gameDate)}</span>
          </div>
        )}

        <div className="flex items-center justify-between gap-4 py-3">
          <div className="flex-1 text-center">
            <div className="w-14 h-14 mx-auto bg-white/5 rounded-2xl flex items-center justify-center mb-2 border border-white/10">
              <span className="text-2xl font-black text-white">{game.homeTeam.charAt(0)}</span>
            </div>
            <p className="font-bold text-white text-sm leading-tight">{game.homeTeam}</p>
          </div>

          <div className="flex flex-col items-center gap-1 shrink-0">
            <div className="bg-primary/10 border border-primary/30 rounded-xl px-4 py-2">
              <span className="text-primary font-black text-xl tracking-widest">{game.matchTime}</span>
            </div>
            <span className="text-[10px] text-white/30 font-bold uppercase">VS</span>
          </div>

          <div className="flex-1 text-center">
            <div className="w-14 h-14 mx-auto bg-white/5 rounded-2xl flex items-center justify-center mb-2 border border-white/10">
              <span className="text-2xl font-black text-white">{game.awayTeam.charAt(0)}</span>
            </div>
            <p className="font-bold text-white text-sm leading-tight">{game.awayTeam}</p>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-white/60">
            <Tv className="w-4 h-4 text-primary shrink-0" />
            <span className="text-sm font-medium">{game.channel}</span>
          </div>
          <div className="flex items-center gap-1.5 text-white/40">
            <Clock className="w-3.5 h-3.5" />
            <span className="text-xs">{game.matchTime}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function GamesPage() {
  const { data: games, isLoading } = useGames();

  const today = new Date().toLocaleDateString('pt-BR');

  const grouped = games?.reduce((acc: Record<string, typeof games>, game) => {
    const key = game.gameDate;
    if (!acc[key]) acc[key] = [];
    acc[key].push(game);
    return acc;
  }, {});

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
          <Trophy className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Jogos do Dia</h1>
          <p className="text-white/50 text-sm mt-0.5">Confira as partidas e onde assistir.</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-white/50">Carregando jogos...</p>
        </div>
      ) : !games || games.length === 0 ? (
        <div className="glass-card rounded-3xl p-12 text-center border-dashed border-white/10">
          <Trophy className="w-12 h-12 text-white/20 mx-auto mb-4" />
          <p className="text-white/50 text-lg font-medium">Nenhum jogo publicado</p>
          <p className="text-white/30 text-sm mt-1">Volte mais tarde para conferir as partidas.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {grouped && Object.entries(grouped)
            .sort(([a], [b]) => {
              const [da, ma, ya] = a.split('/').map(Number);
              const [db, mb, yb] = b.split('/').map(Number);
              return new Date(ya, ma-1, da).getTime() - new Date(yb, mb-1, db).getTime();
            })
            .map(([date, dateGames]) => (
              <div key={date}>
                <div className="flex items-center gap-3 mb-4">
                  <Calendar className="w-5 h-5 text-primary" />
                  <h2 className="text-white font-bold text-lg capitalize">{formatGameDate(date)}</h2>
                  <div className="flex-1 h-px bg-white/10" />
                  <span className="text-xs text-white/30">{dateGames.length} jogo{dateGames.length > 1 ? 's' : ''}</span>
                </div>
                <div className="space-y-4">
                  {dateGames.map((game, i) => (
                    <GameCard key={game.id} game={game} index={i} />
                  ))}
                </div>
              </div>
            ))
          }
        </div>
      )}
    </div>
  );
}
