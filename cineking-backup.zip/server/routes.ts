import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";
declare module "express-session" {
  interface SessionData {
    customerId?: number;
    isAdmin?: boolean;
  }
}

const PostgresStore = connectPgSimple(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.use(
    session({
      store: new PostgresStore({ pool, createTableIfMissing: true }),
      secret: process.env.SESSION_SECRET || "cineking-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 },
    })
  );

  // ── AUTH ─────────────────────────────────────────────
  app.post(api.auth.login.path, async (req, res) => {
    try {
      const { customerCode } = api.auth.login.input.parse(req.body);
      const customer = await storage.getCustomerByCode(customerCode);
      if (!customer) return res.status(401).json({ message: "Código de cliente inválido" });
      req.session.customerId = customer.id;
      req.session.isAdmin = customer.isAdmin;
      res.json(customer);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.auth.me.path, async (req, res) => {
    if (!req.session.customerId) return res.status(401).json({ message: "Não autorizado" });
    const customer = await storage.getCustomer(req.session.customerId);
    if (!customer) return res.status(401).json({ message: "Cliente não encontrado" });
    res.json(customer);
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.session.destroy(() => res.json({ message: "Logout realizado com sucesso" }));
  });

  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.customerId) return res.status(401).json({ message: "Não autorizado" });
    next();
  };

  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.isAdmin) return res.status(401).json({ message: "Acesso restrito a administradores" });
    next();
  };

  // ── CUSTOMERS ─────────────────────────────────────────
  app.get(api.customers.list.path, requireAdmin, async (req, res) => {
    const list = await storage.getCustomers();
    res.json(list);
  });

  app.post(api.customers.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.customers.create.input.parse({
        ...req.body,
        expirationDate: new Date(req.body.expirationDate)
      });
      const newCustomer = await storage.createCustomer(input);
      res.status(201).json(newCustomer);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro ao criar cliente" });
    }
  });

  app.put(api.customers.update.path, requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const updateData = { ...req.body };
      if (updateData.expirationDate) updateData.expirationDate = new Date(updateData.expirationDate);
      const input = api.customers.update.input.parse(updateData);
      const updated = await storage.updateCustomer(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro ao atualizar cliente" });
    }
  });

  app.delete(api.customers.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteCustomer(Number(req.params.id));
    res.status(204).end();
  });

  // ── CONTENT REQUESTS ──────────────────────────────────
  app.post(api.contentRequests.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.contentRequests.create.input.parse({
        ...req.body,
        customerId: req.session.customerId
      });
      const request = await storage.createContentRequest(input);
      res.status(201).json(request);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro interno" });
    }
  });

  app.get(api.contentRequests.list.path, requireAdmin, async (req, res) => {
    const requests = await storage.getContentRequests();
    res.json(requests);
  });

  // ── PROBLEM REPORTS ───────────────────────────────────
  app.post(api.problemReports.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.problemReports.create.input.parse({
        ...req.body,
        customerId: req.session.customerId
      });
      const report = await storage.createProblemReport(input);
      res.status(201).json(report);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro interno" });
    }
  });

  app.get(api.problemReports.list.path, requireAdmin, async (req, res) => {
    const reports = await storage.getProblemReports();
    res.json(reports);
  });

  // ── NOTICES ───────────────────────────────────────────
  app.get(api.notices.list.path, requireAuth, async (req, res) => {
    const list = await storage.getNotices();
    res.json(list);
  });

  app.post(api.notices.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.notices.create.input.parse(req.body);
      const notice = await storage.createNotice(input);
      res.status(201).json(notice);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro interno" });
    }
  });

  app.delete(api.notices.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteNotice(Number(req.params.id));
    res.status(204).end();
  });

  // ── GAMES ─────────────────────────────────────────────
  app.get(api.games.list.path, requireAuth, async (req, res) => {
    const list = await storage.getGames();
    res.json(list);
  });

  app.post(api.games.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.games.create.input.parse(req.body);
      const game = await storage.createGame(input);
      res.status(201).json(game);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro interno" });
    }
  });

  app.put(api.games.update.path, requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.games.update.input.parse(req.body);
      const updated = await storage.updateGame(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Erro interno" });
    }
  });

  app.delete(api.games.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteGame(Number(req.params.id));
    res.status(204).end();
  });

  // Banner upload (saves base64 or URL)
  app.post('/api/games/:id/banner', requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { bannerUrl } = req.body;
      const updated = await storage.updateGame(id, { bannerUrl });
      res.json({ bannerUrl: updated.bannerUrl });
    } catch {
      res.status(500).json({ message: "Erro ao atualizar banner" });
    }
  });

  // ── RECEIPTS ──────────────────────────────────────────
  app.post(api.receipts.upload.path, requireAuth, async (req, res) => {
    res.json({ url: "mock-url", message: "Comprovante enviado com sucesso!" });
  });

  // ── SEED ──────────────────────────────────────────────
  async function seedDatabase() {
    try {
      const existingCustomers = await storage.getCustomers();
      if (existingCustomers.length === 0) {
        await storage.createCustomer({
          customerCode: "ADMIN123",
          name: "Admin CINEKING",
          phone: "0000000000",
          planType: "VIP",
          expirationDate: new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
          status: "Ativo",
          isAdmin: true
        });
        await storage.createCustomer({
          customerCode: "USER123",
          name: "João Silva",
          phone: "11999999999",
          planType: "Mensal",
          expirationDate: new Date(new Date().setDate(new Date().getDate() + 3)),
          status: "Ativo",
          isAdmin: false
        });
      }

      const existingGames = await storage.getGames();
      if (existingGames.length === 0) {
        const today = new Date().toLocaleDateString('pt-BR');
        await storage.createGame({
          homeTeam: "Flamengo",
          awayTeam: "Corinthians",
          matchTime: "20:00",
          championship: "Brasileirão Série A",
          channel: "Globo / SporTV",
          gameDate: today,
        });
        await storage.createGame({
          homeTeam: "Barcelona",
          awayTeam: "Real Madrid",
          matchTime: "17:00",
          championship: "La Liga",
          channel: "ESPN / Disney+",
          gameDate: today,
        });
        await storage.createGame({
          homeTeam: "Manchester City",
          awayTeam: "Arsenal",
          matchTime: "13:30",
          championship: "Premier League",
          channel: "ESPN2",
          gameDate: today,
        });
      }
    } catch (e) {
      console.error("Error seeding DB:", e);
    }
  }

  seedDatabase();

  return httpServer;
}
